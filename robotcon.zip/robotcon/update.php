<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "robot_control";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if direction is received and valid
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["direction"])) {
    $direction = $_POST["direction"];

    // Ensure the direction is valid (F, B, L, R)
    if (in_array($direction, ['F', 'B', 'L', 'R'])) {
        $sql = "INSERT INTO directions (direction) VALUES ('$direction')";
        if ($conn->query($sql) === TRUE) {
            echo "Direction updated successfully";
        } else {
            echo "Error: " . $conn->error;
        }
    } else {
        echo "Invalid direction!";
    }
}

$conn->close();
?>